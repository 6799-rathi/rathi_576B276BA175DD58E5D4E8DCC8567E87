class player:
  def player (self):
    print("the player is playing cricket")
    class batsman(player):
      def play(self):
        print("the batsman is bating")
        class bowler(player):
          def play(self):
            print("the bowler is bowling")